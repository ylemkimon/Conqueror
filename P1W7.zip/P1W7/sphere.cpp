#include <algorithm>
#include "sphere.h"

Sphere::Sphere()
	: center_pos(new float[3]()), radius(0)
{
}

Sphere::Sphere(float x, float y, float z, float r)
	: center_pos(new float[3] {x, y, z}), radius(r)
{
}

Sphere::Sphere(const Sphere& sph)
	: center_pos(new float[3]), radius(sph.radius)
{
	std::copy(sph.center_pos, sph.center_pos + 3, center_pos);
}

Sphere::~Sphere()
{
	delete[] center_pos;
}

Sphere& Sphere::operator=(const Sphere& sph)
{
	if (this != &sph) {
		std::copy(sph.center_pos, sph.center_pos + 3, center_pos);
		radius = sph.radius;
	}
	return *this;
}

void Sphere::setPos(float x, float y, float z)
{
	center_pos[0] = x;
	center_pos[1] = y;
	center_pos[2] = z;
}

void Sphere::setRadius(float r)
{
	radius = r;
}

void Sphere::draw() const {
	/* Draw sphere using glutSolidSphere(), glPushMatrix(), glPopMatrix() */
	glPushMatrix();
	glTranslatef(center_pos[0], center_pos[1], center_pos[2]);
	glutSolidSphere(radius, 10, 10);
	glPopMatrix();

	// Material setting
	float mat_emission[] = { 0.3, 0.0, 0.0, 1.0 };
	float mat_ambient[] = { 1.0, 0.5, 0.2, 1.0 };
	float mat_diffuse[] = { 0.3, 0.5, 0.5, 1.0 };
	float mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	float mat_shininess[] = { 50 };

	glShadeModel(GL_SMOOTH);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
}

inline float Sphere::getX() const
{
	return center_pos[0];
}

inline float Sphere::getY() const
{
	return center_pos[1];
}

inline float Sphere::getZ() const
{
	return center_pos[2];
}

inline float Sphere::getRadius() const
{
	return radius;
}
