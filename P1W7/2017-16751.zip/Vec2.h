#pragma once

#include <algorithm>
#include <GL/glut.h>

using namespace std;

template<typename T>
class Vec2 {
public:
	Vec2();
	Vec2(T x, T y);
	Vec2(const Vec2& v);

	void setPos(T x, T y);
	void draw() const;

	T& operator[](const unsigned int i);
	const T& operator[](const unsigned int i) const;

	template<typename U>
	Vec2& operator+=(const Vec2<U>& v);

	template<typename U>
	Vec2& operator-=(const Vec2<U>& v);

	Vec2& operator*=(T s);
	Vec2& operator/=(T s);

private:
	T pos[2];
};

template<typename T>
inline Vec2<T>::Vec2() : pos()
{
}

template<typename T>
inline Vec2<T>::Vec2(T x, T y) : pos{ x, y }
{
}

template<typename T>
inline Vec2<T>::Vec2(const Vec2& v)
{
	copy(v.pos, v.pos + 2, pos);
}

template<typename T>
inline void Vec2<T>::setPos(T x, T y)
{
	pos[0] = x;
	pos[1] = y;
}

template<typename T>
inline void Vec2<T>::draw() const
{
	glBegin(GL_LINES);
		glVertex2d(0, 0);
		glVertex2d(pos[0], pos[1]);
	glEnd();
	glPointSize(5.f);
		glBegin(GL_POINTS);
		glVertex2d(pos[0], pos[1]);
	glEnd();
}

template<typename T>
inline T& Vec2<T>::operator[](const unsigned int i)
{
	return pos[i];
}

template<typename T>
inline const T& Vec2<T>::operator[](const unsigned int i) const
{
	return pos[i];
}

template<typename T> template<typename U>
inline Vec2<T>& Vec2<T>::operator+=(const Vec2<U>& v)
{
	for (int i = 0; i < 2; i++) {
		pos[i] += v[i];
	}
	return *this;
}

template<typename T> template<typename U>
inline Vec2<T>& Vec2<T>::operator-=(const Vec2<U>& v)
{
	for (int i = 0; i < 2; i++) {
		pos[i] -= v[i];
	}
	return *this;
}

template<typename T>
inline Vec2<T>& Vec2<T>::operator*=(T s)
{
	for (int i = 0; i < 2; i++) {
		pos[i] *= s;
	}
	return *this;
}

template<typename T>
inline Vec2<T>& Vec2<T>::operator/=(T s)
{
	for (int i = 0; i < 2; i++) {
		pos[i] /= s;
	}
	return *this;
}

template<typename T, typename U>
inline Vec2<T> operator+(Vec2<T> v1, const Vec2<U>& v2)
{
	v1 += v2;
	return v1;
}

template<typename T, typename U>
inline Vec2<T> operator-(Vec2<T> v1, const Vec2<U>& v2)
{
	v1 -= v2;
	return v1;
}

template<typename T>
inline Vec2<T> operator*(Vec2<T> v, T s) {
	v *= s;
	return v;
}

template<typename T>
inline Vec2<T> operator/(Vec2<T> v, T s) {
	v /= s;
	return v;
}

template<typename T, typename U>
inline T dotProduct(Vec2<T> a, Vec2<U> b) {
	return a[0] * b[0] + a[1] * b[1];
}
